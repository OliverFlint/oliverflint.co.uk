export function Pointless(message: string): void {
  Xrm.Navigation.openAlertDialog({
    text: message,
    title: "A Pointless Message",
  });
}

export async function CreateAccount(account: any): Promise<Xrm.Lookup> {
  const response = await Xrm.WebApi.createRecord("account", account);
  return response;
}

export class Stuff {
  public foo(): void {
    this.bar();
  }

  private bar(): void {
    Xrm.Navigation.openAlertDialog({
      text: "foo bar",
      title: "A foo bar message",
    });
  }
}
