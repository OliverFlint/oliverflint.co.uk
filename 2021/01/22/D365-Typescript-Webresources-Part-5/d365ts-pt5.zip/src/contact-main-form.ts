import { CallTheWebApi, Pointless, Stuff } from "./sample";

class ContactMainForm {
  public OnLoad(
    executionContext: Xrm.ExecutionContext<Form.contact.Main.Contact, any>
  ) {
    const formContext = executionContext.getFormContext() as Form.contact.Main.Contact;
    formContext.ui.setFormNotification(
      "Typescript locked and loaded!",
      "INFO",
      "ts-msg"
    );
    const parentCustomerAttribute = formContext.getAttribute(
      "parentcustomerid"
    );
    const parentCustomerValue = parentCustomerAttribute.getValue();
    Pointless("This REALLY is a pointless message.");
    const stuff = new Stuff();
    stuff.foo();
    const account = CallTheWebApi();
  }
}
(window as any).ContactMainForm = new ContactMainForm();
