import {
  EntityMock,
  LookupValueMock,
  NavigationStaticMock,
  WebApiMock,
  XrmMockGenerator,
} from "xrm-mock";
import * as sinon from "sinon";
import { CreateAccount, Pointless } from "../src/sample";
describe("sample test", () => {
  beforeEach(() => {
    XrmMockGenerator.initialise();
  });
  describe("Pointless", () => {
    test("Should display alert", () => {
      const stub = sinon.stub(
        NavigationStaticMock.prototype,
        "openAlertDialog"
      );

      const msg = "a pointless test message";
      Pointless(msg);

      expect(stub.called).toBeTruthy();
      expect(stub.calledOnce).toBeTruthy();
      expect(stub.firstCall.args[0].text).toBe(msg);
      expect(stub.firstCall.args[0].title).toBe("A Pointless Message");
    });
  });

  describe("CallTheWebApi", () => {
    test("Should return a valid Xrm.Lookup", async () => {
      const stub = sinon
        .stub(WebApiMock.prototype, "createRecord")
        .withArgs("account", sinon.match.object)
        .resolves({
          entityType: "account",
          id: "9bce6686-48d5-4d6f-85a2-da0eea30984d",
          name: "Jest Account",
        } as LookupValueMock);

      const result: LookupValueMock = await CreateAccount({
        name: "Jest Account",
        creditonhold: false,
        address1_latitude: 47.639583,
        description: "This is the description of the sample account",
        revenue: 5000000,
        accountcategorycode: 1,
      });

      expect(stub.calledOnce).toBeTruthy();
      expect(result).toBeTruthy();
      expect(result.name).toBe("Jest Account");
    });
  });
});
