import { appInsights, addFormContextTelemetryInitializer } from "./appinsights";

class ContactMainForm {
  public OnLoad(
    executionContext: Xrm.ExecutionContext<Form.contact.Main.Contact, any>
  ) {
    const formContext = executionContext.getFormContext() as Form.contact.Main.Contact;
    addFormContextTelemetryInitializer(
      (formContext as unknown) as Xrm.BasicPage
    );
    appInsights.trackPageView();
  }
}
(window as any).ContactMainForm = new ContactMainForm();
