class ContactMainForm {
    static OnLoad(executionContext: any) {
        const formContext = executionContext.getFormContext();
        formContext.ui.setFormNotification("Typescript locked and loaded!", "INFO", "ts-msg");
    }
}