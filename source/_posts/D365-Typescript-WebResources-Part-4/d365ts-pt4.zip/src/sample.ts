export function Pointless(message: string): void {
    Xrm.Navigation.openAlertDialog({text: message, title: "A Pointless Message"});
}

export class Stuff {
    public foo(): void {
        this.bar();
    }

    private bar(): void {
        Xrm.Navigation.openAlertDialog({text: "foo bar", title: "A foo bar message"});
    }
}