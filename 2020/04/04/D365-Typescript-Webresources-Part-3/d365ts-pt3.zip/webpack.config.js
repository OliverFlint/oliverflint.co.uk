module.exports = [{
  mode: 'development',
  entry: {
    "contact-main-form": "./src/contact-main-form"
  },
  output: {
    filename: "[name].js"
  },
  module: {
    rules: [{
      test: /.tsx?$/,
      exclude: /node_modules/,
      loader: "babel-loader"
    }]
  },
  resolve: {
    extensions: [".ts"]
  },
  devtool: "source-map"
},
{
  mode: 'production',
  entry: {
    "contact-main-form": "./src/contact-main-form"
  },
  output: {
    filename: "[name].min.js"
  },
  module: {
    rules: [{
      test: /.tsx?$/,
      exclude: /node_modules/,
      loader: "babel-loader"
    }]
  },
  resolve: {
    extensions: [".ts"]
  },
  devtool: "source-map"
}];